class Node {
  constructor(value, x = 0, y = 0) {
    this.value = value;
    this.left = null;
    this.right = null;
    this.x = x;
    this.y = y;
  }
}

class BST {
  constructor() {
    this.root = null;
  }

  insert(value) {
    const newNode = new Node(value);
    if (!this.root) {
      this.root = newNode;
      return true;
    }
    else {
      return this.insertRec(this.root, newNode);
    }
  }

  insertRec(root, newNode) {
    if (newNode.value < root.value) {
      if (!root.left) {
        root.left = newNode;
        return true;
      }
       else {
        return this.insertRec(root.left, newNode);
      }
    }
     else if (newNode.value > root.value) {
      if (!root.right) {
        root.right = newNode;
        return true;
      }
      else {
        return this.insertRec(root.right, newNode);
      }
    }
     else {
      return false; 
    }
  }

  delete(value) {
    this.root = this.deleteRec(this.root, value);
  }

  deleteRec(root, value) {
    if (!root) return null;
    if (value < root.value){
      root.left = this.deleteRec(root.left, value);
    } 
    else if (value > root.value) root.right = this.deleteRec(root.right, value);
    else {
      if (!root.left) return root.right;
      else if (!root.right) return root.left;
      let minNode = this.findMin(root.right);
      root.value = minNode.value;
      root.right = this.deleteRec(root.right, minNode.value);
    }
    return root;
  }

  findMin(root) {
    while (root.left) root = root.left;
    return root;
  }

  search(value) {
    return this.searchRec(this.root, value);
  }

  searchRec(root, value) {
    if (!root || root.value === value) return root;
    if (value < root.value) return this.searchRec(root.left, value);
    return this.searchRec(root.right, value);
  }
}

const bst = new BST();
const treeContainer = document.getElementById("tree");
const toaster = document.getElementById("toaster");

function drawTree(root, x, y, offset, isRoot = true) {
  if (!root) return;

  const nodeDiv = createNode(root.value, x, y, isRoot);
  treeContainer.appendChild(nodeDiv);

  if (root.left) {
    const leftX = x - offset;
    const leftY = y + 80;
    drawLine(x, y, leftX, leftY);
    drawTree(root.left, leftX, leftY, offset / 1.6, false);
  }

  if (root.right) {
    const rightX = x + offset;
    const rightY = y + 80;
    drawLine(x, y, rightX, rightY);
    drawTree(root.right, rightX, rightY, offset / 1.6, false);
  }
}

function createNode(value, x, y, isRoot = false) {
  const div = document.createElement("div");
  div.className = "node";
  div.textContent = value;
  div.style.left = `${x}px`;
  div.style.top = `${y}px`;
  if (isRoot) {
    div.style.background = "green"; 
  } else {
    div.style.background = "#2563eb";
  }

  gsap.from(div, { scale: 0, duration: 0.4, ease: "back.out(1.7)" });
  return div;
}

function drawLine(x1, y1, x2, y2) {
  const length = Math.hypot(x2 - x1, y2 - y1);
  const angle = Math.atan2(y2 - y1, x2 - x1) * (180 / Math.PI);
  const line = document.createElement("div");
  line.className = "line";
  line.style.width = `${length}px`;
  line.style.left = `${x1 + 25}px`;
  line.style.top = `${y1 + 25}px`;
  line.style.transform = `rotate(${angle}deg)`;
  gsap.from(line, { opacity: 0, duration: 0.4 });
  treeContainer.appendChild(line);
}

function renderTree() {
  treeContainer.innerHTML = "";
  drawTree(bst.root, window.innerWidth / 2 - 25, 50, 200, true);
}

/* ✅ Toaster */
function showToast(message, type = "success") {
  const icon = type === "success" ? "✅" : "❌";
  toaster.className = `toaster ${type}`;
  toaster.innerHTML = `${icon} ${message}`;
  toaster.classList.add("show");

  setTimeout(() => {
    toaster.classList.add("hide");
    setTimeout(() => {
      toaster.classList.remove("show", "hide");
    }, 400);
  }, 3000);
}

/* ✅ Insert Node */
function insertNode() {
  const val = parseInt(document.getElementById("value").value);
  if (isNaN(val)) return showToast("Please enter a number!", "error");

  const added = bst.insert(val);
  if (!added) {
    showToast(`Node ${val} already exists!`, "error");
    return;
  }

  renderTree();
  showToast(`Node ${val} added successfully!`, "success");
}

/* ✅ Delete Node */
function deleteNode() {
  const val = parseInt(document.getElementById("value").value);
  if (isNaN(val)) return showToast("Please enter a number!", "error");
  const found = bst.search(val);
  if (!found) return showToast(`Node ${val} not found!`, "error");
  bst.delete(val);
  renderTree();
  showToast(`Node ${val} deleted successfully!`, "success");
}

/* ✅ Search Node */
function searchNode() {
  const val = parseInt(document.getElementById("value").value);
  if (isNaN(val)) return showToast("Please enter a number!", "error");
  const found = bst.search(val);
  if (found) {
    showToast(`Node ${val} found in tree!`, "success");
  } else {
    showToast(`Node ${val} not found!`, "error");
  }
}
